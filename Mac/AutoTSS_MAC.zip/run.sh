cd /Users/$USER/Documents/AutoTSS
python3 autotss.py -p /Users/$USER/Documents/AutoTSS/tsschecker/tsschecker
